﻿namespace pocenvoie
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1Send = new System.Windows.Forms.TextBox();
            this.ouvrir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2Send = new System.Windows.Forms.TextBox();
            this.close = new System.Windows.Forms.Button();
            this.list = new System.Windows.Forms.TextBox();
            this.send = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(597, 56);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(104, 274);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // textBox1Send
            // 
            this.textBox1Send.Location = new System.Drawing.Point(218, 271);
            this.textBox1Send.Name = "textBox1Send";
            this.textBox1Send.Size = new System.Drawing.Size(100, 22);
            this.textBox1Send.TabIndex = 2;
            this.textBox1Send.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // ouvrir
            // 
            this.ouvrir.Location = new System.Drawing.Point(82, 137);
            this.ouvrir.Name = "ouvrir";
            this.ouvrir.Size = new System.Drawing.Size(75, 23);
            this.ouvrir.TabIndex = 3;
            this.ouvrir.Text = "ouvrir";
            this.ouvrir.UseVisualStyleBackColor = true;
            this.ouvrir.Click += new System.EventHandler(this.ouvrir_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(413, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "label2";
            // 
            // textBox2Send
            // 
            this.textBox2Send.Location = new System.Drawing.Point(582, 265);
            this.textBox2Send.Name = "textBox2Send";
            this.textBox2Send.Size = new System.Drawing.Size(100, 22);
            this.textBox2Send.TabIndex = 5;
            this.textBox2Send.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(625, 149);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(75, 23);
            this.close.TabIndex = 6;
            this.close.Text = "close";
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // list
            // 
            this.list.Location = new System.Drawing.Point(82, 56);
            this.list.Name = "list";
            this.list.Size = new System.Drawing.Size(100, 22);
            this.list.TabIndex = 8;
            this.list.Text = "list";
            // 
            // send
            // 
            this.send.Location = new System.Drawing.Point(375, 367);
            this.send.Name = "send";
            this.send.Size = new System.Drawing.Size(75, 23);
            this.send.TabIndex = 9;
            this.send.Text = "send ";
            this.send.UseVisualStyleBackColor = true;
            this.send.Click += new System.EventHandler(this.send_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.send);
            this.Controls.Add(this.list);
            this.Controls.Add(this.close);
            this.Controls.Add(this.textBox2Send);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ouvrir);
            this.Controls.Add(this.textBox1Send);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1Send;
        private System.Windows.Forms.Button ouvrir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2Send;
        private System.Windows.Forms.Button close;
        private System.Windows.Forms.TextBox list;
        private System.Windows.Forms.Button send;
    }
}

